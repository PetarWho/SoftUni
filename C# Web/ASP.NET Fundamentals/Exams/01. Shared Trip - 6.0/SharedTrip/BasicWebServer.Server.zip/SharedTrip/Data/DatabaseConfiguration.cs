﻿namespace SharedTrip.Data
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
            @"Server=ROY\SQLEXPRESS;Database=FootballManager;Integrated Security = True;";
    }
}