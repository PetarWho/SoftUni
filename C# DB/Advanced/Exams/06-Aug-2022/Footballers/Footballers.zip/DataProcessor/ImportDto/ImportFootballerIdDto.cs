﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Footballers.DataProcessor.ImportDto
{
    public class ImportFootballerIdDto
    {
        public int Id { get; set; }
    }
}
